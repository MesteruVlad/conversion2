#include <fstream>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    int n;
    int cont, p, q=1, s=0;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>cont;
        s+=cont;
        for(int j=1;j<=cont;j++)
        {
            fin>>p;
            if(p>q)
                fout<<q<<" "<<p<<endl;
        }
        q++;
    }
}
